# Publicaciones de Instagram — Team Mylquiades

Orden sugerido para subir: primero el equipo y después uno por uno.
Todos los archivos están en esta carpeta (`out/instagram/`).

| # | Publicación | Reel (1080x1920) | Foto feed (1080x1350, 4:5) |
|---|---|---|---|
| 0 | Equipo completo | `00_equipo_reel.mp4` (30 s) | `00_equipo_foto.jpg` |
| 1 | Pablo Ra (capitán) | `01_pablo_ra_reel.mp4` (5 s) | `01_pablo_ra_foto.jpg` |
| 2 | Felipe "Macizo" Arias | `02_felipe_arias_reel.mp4` | `02_felipe_arias_foto.jpg` |
| 3 | Benjamín Figueroa (BenjaMyL) | `03_benjamin_figueroa_reel.mp4` | `03_benjamin_figueroa_foto.jpg` |
| 4 | Vladi | `04_vladi_reel.mp4` | `04_vladi_foto.jpg` |
| 5 | Alonso Medina | `05_alonso_medina_reel.mp4` | `05_alonso_medina_foto.jpg` |
| 6 | El Victor (nuevo integrante) | `06_el_victor_reel.mp4` (5 s) o `06_el_victor_nuevo_integrante.mp4` (7,5 s, con rótulo de bienvenida) | `06_el_victor_foto.jpg` |

Versiones horizontales 16:9 de El Victor (YouTube, pantallas): `06_el_victor_16x9.mp4` y `06_el_victor_nuevo_integrante_16x9.mp4`.

## Calidad

Exportados a la calidad máxima útil para Instagram (Instagram muestra hasta 1080 px de ancho y recomprime todo):
- Reels: 1080x1920, 30 fps, H.264 High, color BT.709, ~20 Mbps, pista de audio AAC en silencio, "faststart".
- Fotos: 1080x1350 (4:5), JPEG calidad 100 con color completo (4:4:4).

**Importante:** antes de subir, en Instagram activa
*Configuración → Uso de datos y calidad multimedia → Subir con la máxima calidad*.
Sin eso, la app baja la calidad al subir con datos móviles. Mejor subirlas con Wi-Fi.

## Cómo subirlas

- **Reel:** Instagram → + → Reel → elegir el `_reel.mp4`. Los videos no traen música:
  agrega una canción desde la biblioteca de Instagram (así no hay problemas de derechos).
  Como portada del Reel puedes elegir un cuadro del final o subir la `_foto.jpg`.
- **Foto:** Instagram → + → Publicación → elegir la `_foto.jpg`. Ya viene en 4:5, no hay que recortar.
- También puedes subir la foto y el reel juntos como carrusel (primero la foto).

## Textos (cópialos y ajústalos a gusto)

**0 · Equipo**
> Equipo titular. 🃏
> Team Mylquiades sale a la mesa: Pablo Ra (capitán), Felipe "Macizo" Arias, BenjaMyL, Vladi y Alonso Medina.
> #MitosYLeyendas #MyL #TCG #TeamMylquiades

**1 · Pablo Ra**
> Abre la alineación el capitán: Pablo Ra.
> #MitosYLeyendas #MyL #TCG #TeamMylquiades

**2 · Felipe "Macizo" Arias**
> Felipe "Macizo" Arias, presente.
> #MitosYLeyendas #MyL #TCG #TeamMylquiades

**3 · BenjaMyL**
> BenjaMyL entra a la cancha.
> #MitosYLeyendas #MyL #TCG #TeamMylquiades

**4 · Vladi**
> Vladi. Nada más que agregar.
> #MitosYLeyendas #MyL #TCG #TeamMylquiades

**5 · Alonso Medina**
> Cierra la alineación: Alonso Medina.
> #MitosYLeyendas #MyL #TCG #TeamMylquiades

**6 · El Victor (nuevo integrante)**
> Nuevo integrante en Team Mylquiades: bienvenido, El Victor. 🃏
> #MitosYLeyendas #MyL #TCG #TeamMylquiades

Etiqueta a cada uno con su @ de Instagram (no los tengo).
